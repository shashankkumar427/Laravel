<div class="auth-links">
    <a href="<?php echo e(url('/login/github')); ?>" class="btn btn-github"><i class="fa fa-github"></i> Github</a>
    <a href="<?php echo e(url('/login/twitter')); ?>" class="btn btn-twitter" class="btn btn-twitter"><i
                class="fa fa-twitter"></i> Twitter</a>
    <a href="<?php echo e(url('/login/facebook')); ?>" class="btn btn-facebook" class="btn btn-facebook"><i
                class="fa fa-facebook"></i> Facebook</a>
</div><?php /**PATH /home/calvin/Projects/Laravel/Local-Setup/resources/views/vendor/adminlte/social.blade.php ENDPATH**/ ?>